﻿
-- Havayolu Şirketi Veritabanı Oluşturma

-- Havayolu Şirketi Tablosu


---- UÇAK BİLGİLERİ -----
CREATE TABLE UcakBilgileri (
  Id							INT PRIMARY KEY NOT NULL,
  AnaHavayoluMarkasi            NVARCHAR(50) NOT NULL, 
  AltHavayoluMarkasi            NVARCHAR(50) NOT NULL,
  UcakTipi                      NVARCHAR(50) NOT NULL,
  UcagınYası					INT,
);

INSERT INTO UcakBilgileri VALUES (1,'TUI Group','Thomson Airways','Airbus A320','4');
INSERT INTO UcakBilgileri VALUES (2,'All Nippon Airways','All Nippon Airways','Boeing 767','3');
INSERT INTO UcakBilgileri VALUES (3,'Lufthansa','Brussels Airlines','Boeing 737','5');
INSERT INTO UcakBilgileri VALUES (4,'Air India','Air India','Boeing 767','4');
INSERT INTO UcakBilgileri VALUES (5,'EgyptAir','Air Cairo','Airbus A320','1');
INSERT INTO UcakBilgileri VALUES (6,'Finnair','Finnair','ATR 42/72','3');
INSERT INTO UcakBilgileri VALUES (7,'Malaysia Airlines','MASwings','ATR 42/72','11');
INSERT INTO UcakBilgileri VALUES (8,'FedEx Express','FedEx Express','Airbus A310','10');
INSERT INTO UcakBilgileri VALUES (9,'Flybe','Flybe','Embraer ERJ-145','20');
INSERT INTO UcakBilgileri VALUES (10,'Hainan Airlines','Hainan Airlines','Boeing 737','4');
INSERT INTO UcakBilgileri VALUES (11,'Utair','Utair','Boeing 757','5');
INSERT INTO UcakBilgileri VALUES (12,'Air Berlin','Air Berlin','De Havilland Canada DHC-8 Dash 8','6');
INSERT INTO UcakBilgileri VALUES (13,'Royal Jordania','Royal Jordania','Airbus A319','1');
INSERT INTO UcakBilgileri VALUES (14,'Etihad Airways','Etihad Airways','Boeing 777','11');
INSERT INTO UcakBilgileri VALUES (15,'Jazz Airlines','Jazz Airlines','Bombardier Q400 Nextge','13');
INSERT INTO UcakBilgileri VALUES (16,'Kenya Airways','Kenya Airways','McDonnell Douglas DC-9','14');
INSERT INTO UcakBilgileri VALUES (17,'IAG','Iberia','Airbus A321','20');
INSERT INTO UcakBilgileri VALUES (18,'Oman Air','Oman Air','Airbus A330','21');
INSERT INTO UcakBilgileri VALUES (19,'Qantas Airways','Australian Air Express','McDonnell Douglas DC-8','4');
INSERT INTO UcakBilgileri VALUES (20,'Royal Jordania','Royal Jordania','Airbus A321','5');
INSERT INTO UcakBilgileri VALUES (21,'SunExpress','SunExpress Deutschland','Airbus A330','5');
INSERT INTO UcakBilgileri VALUES (22,'Malaysia Airlines','Malaysia Airlines','Boeing 737','6');
INSERT INTO UcakBilgileri VALUES (23,'Aegean Airlines','Aegean Airlines','Airbus A321','6');
INSERT INTO UcakBilgileri VALUES (24,'Atlas Air','Atlas Air','Boeing 737','7');
INSERT INTO UcakBilgileri VALUES (25,'Qantas Airways','QantasLink','British Aerospace BAe 146/Avro RJ','6');
INSERT INTO UcakBilgileri VALUES (26,'Lufthansa','Lufthansa CityLine','Fokker F50 / F60','6');
INSERT INTO UcakBilgileri VALUES (27,'Qatar Airways','Qatar Airways','Boeing 777','3');
INSERT INTO UcakBilgileri VALUES (28,'EVA Air','Uni Air','De Havilland Canada DHC-8 Dash 8','15');
INSERT INTO UcakBilgileri VALUES (29,'Air China','Shenzhen Airlines','Boeing 737','16');
INSERT INTO UcakBilgileri VALUES (30,'Qatar Airways','Qatar Executive','Gulfstream G650ER','15');
INSERT INTO UcakBilgileri VALUES (31,'Air France/KLM','Air France','Fokker F70 / F100','17');
INSERT INTO UcakBilgileri VALUES (32,'Juneyao Airlines','Juneyao Airlines','Airbus A320','18');
INSERT INTO UcakBilgileri VALUES (33,'Qantas Airways','Jetstar Airways','Airbus A321','17');
INSERT INTO UcakBilgileri VALUES (34,'TUI Group','Thomson Airways','Boeing 757','13');
INSERT INTO UcakBilgileri VALUES (35,'Air France/KLM','Air France','Boeing 777','6');
INSERT INTO UcakBilgileri VALUES (36,'Kenya Airways','Kenya Airways','Boeing 757','12');
INSERT INTO UcakBilgileri VALUES (37,'Qantas Airways','Qantas Freight','Boeing 747','16');
INSERT INTO UcakBilgileri VALUES (38,'Aerolineas Argentinas','Aerolineas Argentinas','McDonnell Douglas MD-80','1');
INSERT INTO UcakBilgileri VALUES (39,'Air France/KLM','Air France','Airbus A318','17');
INSERT INTO UcakBilgileri VALUES (40,'Alitalia','Alitalia Cityliner','Canadair CRJ-900','20');
INSERT INTO UcakBilgileri VALUES (41,'Utair','Utair','ATR 42/72','20');
INSERT INTO UcakBilgileri VALUES (42,'Air China','Air China','Boeing 777','29');
INSERT INTO UcakBilgileri VALUES (43,'Air Namibia','Air Namibia','Embraer ERJ-145','15');
INSERT INTO UcakBilgileri VALUES (44,'Japan Airlines','Japan Airlines','Boeing 787 Dreamliner','15');
INSERT INTO UcakBilgileri VALUES (45,'China Eastern Airlines','China Eastern Airlines','Airbus A350','20');
INSERT INTO UcakBilgileri VALUES (46,'Air India','Air India','McDonnell Douglas DC-8','22');
INSERT INTO UcakBilgileri VALUES (47,'Air Canada','Air Canada Jetz','Boeing 737','24');
INSERT INTO UcakBilgileri VALUES (48,'Frontier Airlines','Frontier Airlines','Airbus A321','26');
INSERT INTO UcakBilgileri VALUES (49,'Aeroflot','Aeroflot','Airbus A321','22');
INSERT INTO UcakBilgileri VALUES (50,'Air Astana','Air Astana','Boeing 787','27');
INSERT INTO UcakBilgileri VALUES (51,'Aerolineas Argentinas','Aerolineas Argentinas','Airbus A330','11');
INSERT INTO UcakBilgileri VALUES (52,'Virgin Australia','Virgin Australia Regional','Airbus A320','10');
INSERT INTO UcakBilgileri VALUES (53,'Gol Linhas Aéreas','Gol Linhas Aéreas','Boeing 737','10');
INSERT INTO UcakBilgileri VALUES (54,'Skywest','Skywest','Canadair CRJ-900','15');
INSERT INTO UcakBilgileri VALUES (55,'Delta Airlines','Delta Airlines','Boeing 787 Dreamliner','13');
INSERT INTO UcakBilgileri VALUES (56,'All Nippon Airways','ANA Wings','Mitsubishi MRJ90','14');
INSERT INTO UcakBilgileri VALUES (57,'American Airlines','American Airlines','Boeing 787 Dreamliner','15');
INSERT INTO UcakBilgileri VALUES (58,'Philippine Airlines','Philippine Airlines','Airbus A319','20');
INSERT INTO UcakBilgileri VALUES (59,'China Eastern Airlines','China Eastern Airlines','Embraer ERJ-145','5');
INSERT INTO UcakBilgileri VALUES (60,'Qatar Airways','Qatar Airways','Boeing 787 Dreamliner','15');
INSERT INTO UcakBilgileri VALUES (61,'Alaska Airlines','Horizon Air','De Havilland Canada DHC-8 Dash 8','6');
INSERT INTO UcakBilgileri VALUES (62,'Air China','Air China','Airbus A330','3');
INSERT INTO UcakBilgileri VALUES (63,'China Eastern Airlines','China Eastern Airlines','Airbus A310','8');
INSERT INTO UcakBilgileri VALUES (64,'Southwest Airlines','Southwest Airlines','Boeing 737','35');
INSERT INTO UcakBilgileri VALUES (65,'Jet Airways','Jet Airways','ATR 42/72','15');
INSERT INTO UcakBilgileri VALUES (66,'China Eastern Airlines','China Eastern Airlines','Boeing 767','12');
INSERT INTO UcakBilgileri VALUES (67,'Grupo Aeromexico','Aeromexico','Boeing 737','24');
INSERT INTO UcakBilgileri VALUES (68,'Lufthansa','Lufthansa Cargo','McDonnell Douglas DC-10','26');
INSERT INTO UcakBilgileri VALUES (69,'Cebu Pacific Air','Cebu Pacific Air','Airbus A330','26');
INSERT INTO UcakBilgileri VALUES (70,'Aeroflot','Rossiya Airlines','Antonov An-124','26');
INSERT INTO UcakBilgileri VALUES (71,'IAG','Aer Lingus Regional','ATR 42/72','21');
INSERT INTO UcakBilgileri VALUES (72,'Norwegian Air','Norwegian UK','Boeing 787 Dreamliner','27');
INSERT INTO UcakBilgileri VALUES (73,'Air Berlin','Air Berlin','Embraer ERJ-190','10');
INSERT INTO UcakBilgileri VALUES (74,'Tunisair','Tunisair','McDonnell Douglas DC-10','9');
INSERT INTO UcakBilgileri VALUES (75,'Air China','Dalian Airlines (80%)','Boeing 737','6');
INSERT INTO UcakBilgileri VALUES (76,'Air France/KLM','HOP!','Canadair CRJ-1000','7');
INSERT INTO UcakBilgileri VALUES (77,'TUI Group','TUI Airlines Belgium','Boeing 737','8');
INSERT INTO UcakBilgileri VALUES (78,'Jet Airways','Jet Airways','Boeing 777','3');
INSERT INTO UcakBilgileri VALUES (79,'Philippine Airlines','Philippine Airlines','Airbus A320','3');
INSERT INTO UcakBilgileri VALUES (80,'Hawaiian Airlines','Hawaiian Airlines','McDonnell Douglas DC-8','3');
INSERT INTO UcakBilgileri VALUES (81,'EVA Air','EVA Air','ATR 42/72','1');
INSERT INTO UcakBilgileri VALUES (82,'Malaysia Airlines','Malaysia Airlines','Airbus A330','0');
INSERT INTO UcakBilgileri VALUES (83,'IndiGo','IndiGo','Airbus A320','0');
INSERT INTO UcakBilgileri VALUES (84,'Lufthansa','Brussels Airlines','Boeing 737','0');
INSERT INTO UcakBilgileri VALUES (85,'Philippine Airlines','Philippine Airlines','Airbus A300','0');




--- ÇALIŞANLAR ------
create table Çalışanlar (
Ad VARCHAR(100) NOT NULL,
Soyad VARCHAR(100) NOT NULL,
yas INT NOT NULL,
Cinsiyet VARCHAR(20) not null,

);

INSERT INTO Çalışanlar VALUES ('Ahmet', 'Yılmaz', 28, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Ayşe', 'Kaya', 35, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Mehmet', 'Demir', 42, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Fatma', 'Aydın', 31, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Emre', 'Öztürk', 27, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Zeynep', 'Korkmaz', 29, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Mustafa', 'Şahin', 39, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Seda', 'Turan', 34, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Berkay', 'Yıldız', 30, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Elif', 'Koç', 33, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Ali', 'Aydın', 43, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Esra', 'Çelik', 28, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Murat', 'Kara', 37, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Gizem', 'Kurt', 29, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Ahmet', 'Koç', 36, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Ayşe', 'Yıldız', 31, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Mehmet', 'Aydın', 40, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Fatma', 'Şahin', 26, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Emre', 'Turan', 35, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Zeynep', 'Yılmaz', 38, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Mustafa', 'Kara', 32, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Seda', 'Koç', 27, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Berkay', 'Öztürk', 33, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Elif', 'Kaya', 30, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Ali', 'Çelik', 42, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Esra', 'Demir', 31, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Murat', 'Yıldız', 37, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Gizem', 'Koç', 29, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Ahmet', 'Şahin', 36, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Ayşe', 'Turan', 31, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Mehmet', 'Kara', 40, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Fatma', 'Koç', 26, 'Kadın');
INSERT INTO Çalışanlar VALUES  ('Emre', 'Yılmaz', 35, 'Erkek');
INSERT INTO Çalışanlar VALUES  ('Zeynep', 'Aydın', 38, 'Kadın');





----- CİNSİYET -------

Create table Cinsiyet(
Id INT PRIMARY KEY NOT NULL,
Cinsiyet NVARCHAR(1) NOT NULL,
);

INSERT INTO Cinsiyet VALUES (1,'E');
INSERT INTO Cinsiyet VALUES (2,'K');




------ Yolcular Tablosu -------
CREATE TABLE Yolcular (
    YolcuID INT PRIMARY KEY,
    Ad VARCHAR(100) NOT NULL,
    Soyad VARCHAR(100) NOT NULL,
	yas INTEGER,
	c_id INT FOREIGN KEY REFERENCES Cinsiyet(id),	
    U_ıd INT FOREIGN KEY REFERENCES UcakBilgileri(Id),

);

INSERT INTO Yolcular VALUES (1,'Bora','Ekiz',15,1,65);
INSERT INTO Yolcular VALUES (2,'Serhat','Kandemir',19,1,72); 
INSERT INTO Yolcular VALUES (3,'Yiğit','Demirel',20,1,55); 
INSERT INTO Yolcular VALUES (4,'Enes','Sizo',24,1,75); 
INSERT INTO Yolcular VALUES (5,'Selçuk','Şahin',26,1,12); 
INSERT INTO Yolcular VALUES (6,'Bahar','Candan',21,2,1); 
INSERT INTO Yolcular VALUES (7,'Cansel','Taş',11,2,7); 
INSERT INTO Yolcular VALUES (8,'Buket','Tut',21,2,76); 
INSERT INTO Yolcular VALUES (9,'Arda','Güler',31,1,48); 
INSERT INTO Yolcular VALUES (10,'Cem','Şeker',42,1,31); 
INSERT INTO Yolcular VALUES (11,'Aslı','Karaduman',52,2,37); 
INSERT INTO Yolcular VALUES (12,'Sedat','Peker',61,1,61); 
INSERT INTO Yolcular VALUES (13,'Veysel','Akpınar',63,1,62); 
INSERT INTO Yolcular VALUES (14,'Yaren','Kapı',64,2,58); 
INSERT INTO Yolcular VALUES (15,'Irına','Olga',35,2,57); 
INSERT INTO Yolcular VALUES (16,'Irfancan','Çayçı',32,1,13); 
INSERT INTO Yolcular VALUES (17,'Ardınç','Çelik',24,1,79); 
INSERT INTO Yolcular VALUES (18,'Burak','Kandemir',22,1,71); 
INSERT INTO Yolcular VALUES (19,'Deniz','Öztürk',20,2,35); 
INSERT INTO Yolcular VALUES (20,'Fatma','Yılmaz',10,2,37); 
INSERT INTO Yolcular VALUES (21,'Aylin','Karadağ',19,2,40); 
INSERT INTO Yolcular VALUES (22,'Cemal ','Kızgın',18,1,23); 
INSERT INTO Yolcular VALUES (23,'Esra','Ekiz',18,2,11); 
INSERT INTO Yolcular VALUES (24,'Yasemin','Yılmaz',18,2,7); 
INSERT INTO Yolcular VALUES (25,'Yasemin','Şahin',18,2,3); 
INSERT INTO Yolcular VALUES (26,'Mustafa ','Kemal',28,1,8); 
INSERT INTO Yolcular VALUES (27,'Çoşkun','Özbek',23,1,81); 
INSERT INTO Yolcular VALUES (28,'Ali ','Ekiz',33,1,83); 
INSERT INTO Yolcular VALUES (29,'Yunus','Yılmaz',42,1,84); 
INSERT INTO Yolcular VALUES (30,'Melih','Ekiz',41,1,55); 
INSERT INTO Yolcular VALUES (31,'Ferhat','Yılmaz',42,2,31);
INSERT INTO Yolcular VALUES (32,'Nazlı','Ekiz',18,2,27); 
INSERT INTO Yolcular VALUES (33,'Zehra','Şimşek',6,2,48); 
INSERT INTO Yolcular VALUES (34,'İlayda','Şimşek',7,2,76); 
INSERT INTO Yolcular VALUES (35,'Merve','Erdoğan',33,2,54); 
INSERT INTO Yolcular VALUES (36,'Yağmur','Kaplan',65,2,56); 
INSERT INTO Yolcular VALUES (37,'Elif','Kaya',55,2,57); 
INSERT INTO Yolcular VALUES (38,'Sude','Şimşek',74,2,41); 
INSERT INTO Yolcular VALUES (39,'Ayşegül','Erdoğan',14,2,42); 
INSERT INTO Yolcular VALUES (40,'Sıla','Erdoğan',26,2,66); 
INSERT INTO Yolcular VALUES (41,'Mehmet','Ekiz',27,1,63); 
INSERT INTO Yolcular VALUES (42,'Onur','Tekin',26,1,5); 
INSERT INTO Yolcular VALUES (43,'İlkay','Şimşek',16,1,22); 
INSERT INTO Yolcular VALUES (44,'Doğan','Ekiz',18,1,24); 
INSERT INTO Yolcular VALUES (45,'Oğuzhan','Ekiz',23,1,49); 
INSERT INTO Yolcular VALUES (46,'Cem','İnan',26,1,56); 
INSERT INTO Yolcular VALUES (47,'Serkan','Toprak',17,1,1); 
INSERT INTO Yolcular VALUES (48,'Uğur','Aydın',18,1,2); 
INSERT INTO Yolcular VALUES (49,'Onur','Demir',80,1,3); 
INSERT INTO Yolcular VALUES (50,'Bayram','Kaan',45,1,9); 
INSERT INTO Yolcular VALUES (51,'Deniz','Avcı',31,1,14); 
INSERT INTO Yolcular VALUES (52,'Diyar','Arslan',30,1,17); 
INSERT INTO Yolcular VALUES (53,'Sinem','Öztürk',20,2,20); 
INSERT INTO Yolcular VALUES (54,'Özlem','Özbek',7,2,21); 
INSERT INTO Yolcular VALUES (55,'Tuğçe','Özdemir',33,2,29); 
INSERT INTO Yolcular VALUES (56,'Pınar','Ayaz',14,2,13); 
INSERT INTO Yolcular VALUES (57,'Yaprak','Topaloğlu',33,2,49); 
INSERT INTO Yolcular VALUES (58,'Metin','Alioğlu',33,1,56); 
INSERT INTO Yolcular VALUES (59,'Bayram','Kılıç',20,1,71); 
INSERT INTO Yolcular VALUES (60,'Sami','Lale',20,1,69); 
INSERT INTO Yolcular VALUES (61,'Seda','Aksoy',20,2,18); 
INSERT INTO Yolcular VALUES (62,'Oğuz','Kaya',37,1,17); 
INSERT INTO Yolcular VALUES (63,'İlayda','Kaya',25,2,16); 
INSERT INTO Yolcular VALUES (64,'Selin','Yılmaz',20,2,15); 
INSERT INTO Yolcular VALUES (65,'Kaan','Atasoy',34,1,13); 
INSERT INTO Yolcular VALUES (66,'Eda','Güler',28,2,10); 




-------- UÇAK BİLGİLERİ İLE İLGİLİ SORGULAR --------
----------------------------------------------------

select * from UcakBilgileri

-------- UÇAĞIN YAŞI 20 DEN BÜYÜK OLANLARI LİSTELE --------

select * from UcakBilgileri where UcagınYası>=20

-------- UÇAĞIN YAŞI 10 DAN BÜYÜK OLUP UCAK TİPİ AİRBUS A321 OLANLARI LİSTELE --------

select * from UcakBilgileri where UcagınYası>=10 and UcakTipi='Airbus A321'

--------  Ana havayolu markası adı A ile başlayanları lİstele --------

select * from UcakBilgileri where AnaHavayoluMarkasi LIKE 'A%'

-------- Ana Havayolu adı Air China olup Uçağın yaşı 20 den büyük olanları listele --------

select * from UcakBilgileri where AnaHavayoluMarkasi='Air China' and UcagınYası>=20

-------- UÇAĞIN YAŞINI BÜYÜKTEN KÜÇÜĞE DOĞRU SIRALAMA --------
select * from UcakBilgileri order by UcagınYası DESC








-------- ÇALIŞANLARIN BİLGİLERİ İLE İLGİLİ SORGULAR --------
------------------------------------------------------------

select * from Çalışanlar

-------- Çalışanlardan Adı A ile başlayıp Cinsiyeti erkek Olanları Listeleme --------

select * from Çalışanlar where Ad LIKE 'A%' AND Cinsiyet='Erkek'


-------- Sadece Cinsiyeti Kadın olanları Listeleme --------

 select * from Çalışanlar where Cinsiyet='Kadın'


 -------- Soyadı Yıldız ve yaşı 20 den büyük olanları listele --------

 select * from Çalışanlar where Soyad='Yıldız' and yas>=20

 -------- Cinsiyeti kadın olup yaşı 20 den büyük olanları Listele --------

 select * from Çalışanlar where Cinsiyet='Kadın' and yas>=20


 -------- Adı A ile başlayıp Soyadı K ile başlayıp Cinsiyeti Kadın olanları Listele --------
 
 select * from Çalışanlar where Ad LIKE 'A%' and Soyad LIKE 'K%' and Cinsiyet='Kadın'







 -------- YOLCULARIN BİLGİLERİ İLE İLGİLİ SORGULAR --------
------------------------------------------------------------

select * from Yolcular

-------- Yolculardan Adı B ile başlayıp ATR 42/72 ile uçanları listele --------
select Y.Ad,Y.Soyad,Y.yas,u.AltHavayoluMarkasi,U.UcakTipi from UcakBilgileri U
INNER JOIN Yolcular Y ON U.Id=Y.U_ıd
where Y.Ad LIKE 'B%' and U.UcakTipi='ATR 42/72'



-------- En genç uçak yaşıyla uçan Yolculardan ilk 10 listeleme --------
select TOP 10 Y.Ad,Y.Soyad,Y.yas,U.AnaHavayoluMarkasi,u.AltHavayoluMarkasi,U.UcakTipi,u.UcagınYası from UcakBilgileri U 
INNER JOIN Yolcular Y ON U.Id=Y.U_ıd
ORDER BY U.UcagınYası ASC


-------- Yaşı 18 den büyük ve Airbus A319 ile uçan yolcuları listele --------
select Y.Ad,Y.Soyad,Y.yas,U.AnaHavayoluMarkasi,u.AltHavayoluMarkasi,U.UcakTipi,u.UcagınYası from UcakBilgileri U 
INNER JOIN Yolcular Y ON U.Id=Y.U_ıd
where yas>=18 and u.UcakTipi='Airbus A319'


-------- Cinsiyeti kız olan Yolcuları ve Uçtuğu uçağın adını listele --------
select  Y.Ad,Y.Soyad,C.Cinsiyet,Y.yas,U.UcakTipi from UcakBilgileri U 
INNER JOIN Yolcular Y ON U.Id=Y.U_ıd
INNER JOIN Cinsiyet C on C.Id=Y.c_id

where C.Cinsiyet='K'


-------- Cinsiyeti Kız olup yaşı 27 den büyük olan yolcuları Listele --------


select Y.Ad,Y.Soyad,Y.yas,C.Cinsiyet from Cinsiyet C
INNER JOIN Yolcular Y ON C.Id=Y.c_id

where C.Cinsiyet='K' and Y.yas>=27


